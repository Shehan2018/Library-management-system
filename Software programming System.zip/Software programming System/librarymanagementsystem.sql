
-- SQL Dump Converted from XML
-- Database: librarymanagementsystem

CREATE TABLE `account` (
  `Username` varchar(30) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Sec_Q` varchar(30) NOT NULL,
  `Answer` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `issuebook` (
  `ApplicationNo` varchar(20) NOT NULL,
  `BName` varchar(60) DEFAULT NULL,
  `Author` varchar(70) DEFAULT NULL,
  `P_Published` varchar(100) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `MembershipNo` varchar(30) DEFAULT NULL,
  `MName` varchar(100) DEFAULT NULL,
  `MNIC_No` varchar(12) DEFAULT NULL,
  `MTell_No` varchar(12) DEFAULT NULL,
  `GName` varchar(100) DEFAULT NULL,
  `GTell_No` varchar(12) DEFAULT NULL,
  `DoIssue` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `memberdetails` (
  `MembershipNo` int(11) NOT NULL AUTO_INCREMENT,
  `MName` varchar(60) NOT NULL,
  `MAddress` varchar(100) NOT NULL,
  `DoF` date NOT NULL,
  `MNIC` varchar(12) NOT NULL,
  `Gender` varchar(7) NOT NULL,
  `MJOB` varchar(20) NOT NULL,
  `MTell_No` varchar(12) NOT NULL,
  `GName` varchar(60) NOT NULL,
  `GAddress` varchar(100) NOT NULL,
  `GNIC` varchar(12) NOT NULL,
  `GTell_No` varchar(11) NOT NULL,
  `GJOB` varchar(20) NOT NULL,
  PRIMARY KEY (`MembershipNo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `newbook` (
  `ApplicationNo` int(15) NOT NULL AUTO_INCREMENT,
  `BName` varchar(100) NOT NULL,
  `Author` varchar(60) NOT NULL,
  `P_Published` varchar(100) NOT NULL,
  `D_Published` date NOT NULL,
  `Price` double NOT NULL,
  `Pages` int(11) NOT NULL,
  `Type_No` int(11) NOT NULL,
  `Language` varchar(20) NOT NULL,
  PRIMARY KEY (`ApplicationNo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `removebook` (
  `ApplicationNo` int(15) NOT NULL AUTO_INCREMENT,
  `BName` varchar(100) NOT NULL,
  `Author` varchar(60) NOT NULL,
  `P_Published` varchar(100) NOT NULL,
  `D_Published` date NOT NULL,
  `Price` double NOT NULL,
  `Pages` int(11) NOT NULL,
  `Type_No` int(11) NOT NULL,
  `Language` varchar(20) NOT NULL,
  PRIMARY KEY (`ApplicationNo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `returnbook` (
  `ApplicationNo` varchar(10) NOT NULL,
  `BName` varchar(100) DEFAULT NULL,
  `Author` varchar(100) DEFAULT NULL,
  `P_Published` varchar(100) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `Pages` int(11) DEFAULT NULL,
  `MembershipNo` varchar(20) NOT NULL,
  `MName` varchar(100) DEFAULT NULL,
  `MNIC_No` varchar(12) DEFAULT NULL,
  `MTell_No` varchar(12) DEFAULT NULL,
  `GName` varchar(100) DEFAULT NULL,
  `GTell_No` varchar(12) DEFAULT NULL,
  `DoIssue` date DEFAULT NULL,
  `DoReturn` date DEFAULT NULL,
  `Fines` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `staff` (
  `SNIC` varchar(12) NOT NULL,
  `SName` varchar(70) DEFAULT NULL,
  `Jobtitle` varchar(50) DEFAULT NULL,
  `SAddress` varchar(100) DEFAULT NULL,
  `SDoB` date DEFAULT NULL,
  `SGender` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`SNIC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `tool` (
  `ApplicationNo` varchar(20) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`ApplicationNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
